BMX-NG is compatible alternative to BlitzMax enabling 64bit compilation
and other targets.

Licence:
  Modules: zLib/libPNG or other (PD or another FOSS one)
  BCC: zLib/libPNG

--------------------------

bin64 contains 64bit variants of bcc/bmk/..., but this should not be
needed even on 64 bit platforms.

If you desire, switch bin and bin64.

--------------------------

Created with setup script available at
https://github.com/bmx-ng/
